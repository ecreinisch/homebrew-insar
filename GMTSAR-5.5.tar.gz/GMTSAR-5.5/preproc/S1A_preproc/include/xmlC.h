/*
  Include file for xml code written by Eric Xu, April 6, 2015
*/
typedef struct tree{
    char name[200];
    int sibr;
    int sibl;
    int parent;
    int firstchild;
}tree;
